-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2020 at 03:03 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `blog_using_laravel_vue_js`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_title` varchar(155) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_name` varchar(155) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `rank_order` int(11) DEFAULT '0',
  `seo_title` mediumtext COLLATE utf8mb4_unicode_ci,
  `seo_meta_title` mediumtext COLLATE utf8mb4_unicode_ci,
  `seo_keywords` mediumtext COLLATE utf8mb4_unicode_ci,
  `seo_content` mediumtext COLLATE utf8mb4_unicode_ci,
  `seo_meta_content` mediumtext COLLATE utf8mb4_unicode_ci,
  `registered_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_title`, `category_name`, `status`, `rank_order`, `seo_title`, `seo_meta_title`, `seo_keywords`, `seo_content`, `seo_meta_content`, `registered_date`) VALUES
(3, 'ইলেকট্রনিক্স পণ্য', 'ইলেকট্রনিক্স পণ্য', 1, 3, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(4, 'ছেলেদের শপিং', 'ছেলেদের শপিং', 1, 4, NULL, NULL, NULL, NULL, NULL, '2020-08-15 00:00:00'),
(53, 'কসমেটিক্স', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-10-15 06:40:25'),
(57, 'Laptop kina', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-10-15 06:44:05'),
(58, 'Mango', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-10-20 06:52:01'),
(59, 'Alu Product', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-10-20 06:54:01'),
(60, 'Jackfuirt', NULL, 1, 0, NULL, NULL, NULL, NULL, NULL, '2020-10-20 06:54:19');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL,
  `post_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '1 active 0 in active',
  `visitor` bigint(20) NOT NULL DEFAULT '0',
  `modified_time` datetime NOT NULL,
  `folder` int(11) NOT NULL,
  `feasured_image` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_time` varchar(230) COLLATE utf8mb4_unicode_ci NOT NULL,
  `seo_title` varchar(230) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keywords` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_content` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `post_title`, `user`, `post_name`, `post_description`, `status`, `visitor`, `modified_time`, `folder`, `feasured_image`, `created_time`, `seo_title`, `seo_keywords`, `seo_content`) VALUES
(3, 'একদিন সব হেফাজতে মৃত্যুর বিচার হবে', 'Shajidul rohman', 'ttttt', NULL, 1, 34, '2020-09-25 10:04:21', 3, '3.13.390a54e1-358f-c77c-32aa-08d6613ae3fe_400x400.jpg', '2020-09-11 14:59:48', 'd ggg', 'fdd ggg', 'df gg'),
(4, '২৪ ঘণ্টায় করোনা শনাক্ত ১৭৯২, মৃত্যু ৩৪', 'ss', 'computer-component', NULL, 1, 7, '2020-09-11 23:21:21', 4, '4.116146511_140944227689428_5878306384722124065_n.jpg', '2020-09-11 15:07:30', 'ggggrrr', 'ttttt', 'ggggrrrrrrrrr'),
(5, 'মিছিলে​ হঠাৎ সরব নয়াপল্টন', 'ss', 'polton', '<p>dd</p>', 1, 20, '2020-09-11 19:55:05', 5, '5.10.7-510x510.jpg', '2020-09-11 19:37:42', 'd', 'dddd', 'd'),
(6, 'শেফালির ভূমিকায় ফারজানা ছবি মানসিক ভারসাম্যহীন শেফালি ও তার সন্তান', 'ss', 'ffff', '<p>দয়ারামপুরের আঁটি গ্রামে বাজারের কাছে স্কুল। স্কুলমাঠের পাশে শতবর্ষী বটগাছ। তারই এক কোণে সংসার পেতেছে শেফালি। মানসিক ভারসাম্যহীন শেফালির বয়স আর কত হবে, ২৫ বা ২৬। কবে, কোত্থেকে, কীভাবে শেফালি এই গ্রামে এসেছে, তা কারও জানা নেই। এ নিয়ে কারও ভাবনাও নেই। ক্ষুধাই শেফালির জগতের একমাত্র চিন্তা।</p>\r\n\r\n<p>নাটকটি পরিচালনা করেছেন আলমগীর সাগর ও আতিকুর রহমান। সিনেমা বানানোর স্বপ্নে বিভোর এই পরিচালকদ্বয় বললেন, &lsquo;এখনকার অস্থির বাস্তবতায় নাটক মানে দাঁড়িয়েছে সেই চর্বিত চর্বণ, তথাকথিত প্রেম আর জোর করে হাসানো হাস্যরসাত্মক গল্প। এমন সময়ে একটি ভিন্নধারার বাস্তবধর্মী গল্প নিয়ে কাজ করাটা ঝুঁকিপূর্ণ আর চ্যালেঞ্জিংও বটে। তবে আমরা সেই চ্যালেঞ্জই নিতে চেয়েছি। একটি ভালো কাজের জন্য সবার আন্তরিকতা আর সহযোগিতা আমাদের স্পর্শ করেছে। এই দুর্যোগকালে অনেক মানুষের সঙ্গে মিলে কাজটা করা। বিশেষ করে, গ্রামের মানুষের সহযোগিতা ছাড়া কাজটা সম্ভব করা হতো না। আশা করছি, দর্শকদের ভালো একটা কাজ উপহার দিতে পারব।&rsquo;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>নাটকটি পরিচালনা করেছেন আলমগীর সাগর ও আতিকুর রহমান। সিনেমা বানানোর স্বপ্নে বিভোর এই পরিচালকদ্বয় বললেন, &lsquo;এখনকার অস্থির বাস্তবতায় নাটক মানে দাঁড়িয়েছে সেই চর্বিত চর্বণ, তথাকথিত প্রেম আর জোর করে হাসানো হাস্যরসাত্মক গল্প। এমন সময়ে একটি ভিন্নধারার বাস্তবধর্মী গল্প নিয়ে কাজ করাটা ঝুঁকিপূর্ণ আর চ্যালেঞ্জিংও বটে। তবে আমরা সেই চ্যালেঞ্জই নিতে চেয়েছি। একটি ভালো কাজের জন্য সবার আন্তরিকতা আর সহযোগিতা আমাদের স্পর্শ করেছে। এই দুর্যোগকালে অনেক মানুষের সঙ্গে মিলে কাজটা করা। বিশেষ করে, গ্রামের মানুষের সহযোগিতা ছাড়া কাজটা সম্ভব করা হতো না। আশা করছি, দর্শকদের ভালো একটা কাজ উপহার দিতে পারব।&rsquo;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>নাটকটি পরিচালনা করেছেন আলমগীর সাগর ও আতিকুর রহমান। সিনেমা বানানোর স্বপ্নে বিভোর এই পরিচালকদ্বয় বললেন, &lsquo;এখনকার অস্থির বাস্তবতায় নাটক মানে দাঁড়িয়েছে সেই চর্বিত চর্বণ, তথাকথিত প্রেম আর জোর করে হাসানো হাস্যরসাত্মক গল্প। এমন সময়ে একটি ভিন্নধারার বাস্তবধর্মী গল্প নিয়ে কাজ করাটা ঝুঁকিপূর্ণ আর চ্যালেঞ্জিংও বটে। তবে আমরা সেই চ্যালেঞ্জই নিতে চেয়েছি। একটি ভালো কাজের জন্য সবার আন্তরিকতা আর সহযোগিতা আমাদের স্পর্শ করেছে। এই দুর্যোগকালে অনেক মানুষের সঙ্গে মিলে কাজটা করা। বিশেষ করে, গ্রামের মানুষের সহযোগিতা ছাড়া কাজটা সম্ভব করা হতো না। আশা করছি, দর্শকদের ভালো একটা কাজ উপহার দিতে পারব।&rsquo;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>', 1, 19, '2020-09-11 21:57:02', 6, '6.100.0168544_organic-mustard-oil-sorisa-kather-ghani-1l_550.jpeg', '2020-09-11 20:02:21', NULL, NULL, NULL),
(7, 'শিক্ষায়তনিক ‘চৌর্যবৃত্তি’: কী হয় আর কী করা উচিত', 'Shajidul rohman', 'eduction ki ho', '<p>শিক্ষায়তনিক সততাকে ইংরেজিতে বলে academic integrity। তা ভঙ্গ করে কেউ যখন অন্য কোনো লেখকের&ndash;গবেষকের প্রকাশিত লেখা বা তার অংশবিশেষ ওই লেখককে বা প্রকাশনাকে উল্লেখ না করে নিজের নামে ছাপেন বা নিজের বুদ্ধিবৃত্তিক অবদান বলে দাবি করেন (প্রকাশনার মাধ্যমে), তখন এই কাজটাকে শিক্ষায়তনিক অসদাচরণ বলে। সহজ বাংলায় যা &#39;চৌর্যবৃত্তি&#39; (plagiarism)।</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>শিক্ষায়তনিক সততাকে ইংরেজিতে বলে academic integrity। তা ভঙ্গ করে কেউ যখন অন্য কোনো লেখকের&ndash;গবেষকের প্রকাশিত লেখা বা তার অংশবিশেষ ওই লেখককে বা প্রকাশনাকে উল্লেখ না করে নিজের নামে ছাপেন বা নিজের বুদ্ধিবৃত্তিক অবদান বলে দাবি করেন (প্রকাশনার মাধ্যমে), তখন এই কাজটাকে শিক্ষায়তনিক অসদাচরণ বলে। সহজ বাংলায় যা &#39;চৌর্যবৃত্তি&#39; (plagiarism)।</p>\r\n\r\n<p>শিক্ষায়তনিক সততাকে ইংরেজিতে বলে academic integrity। তা ভঙ্গ করে কেউ যখন অন্য কোনো লেখকের&ndash;গবেষকের প্রকাশিত লেখা বা তার অংশবিশেষ ওই লেখককে বা প্রকাশনাকে উল্লেখ না করে নিজের নামে ছাপেন বা নিজের বুদ্ধিবৃত্তিক অবদান বলে দাবি করেন (প্রকাশনার মাধ্যমে), তখন এই কাজটাকে শিক্ষায়তনিক অসদাচরণ বলে। সহজ বাংলায় যা &#39;চৌর্যবৃত্তি&#39; (plagiarism)।</p>\r\n\r\n<p>শিক্ষায়তনিক সততাকে ইংরেজিতে বলে academic integrity। তা ভঙ্গ করে কেউ যখন অন্য কোনো লেখকের&ndash;গবেষকের প্রকাশিত লেখা বা তার অংশবিশেষ ওই লেখককে বা প্রকাশনাকে উল্লেখ না করে নিজের নামে ছাপেন বা নিজের বুদ্ধিবৃত্তিক অবদান বলে দাবি করেন (প্রকাশনার মাধ্যমে), তখন এই কাজটাকে শিক্ষায়তনিক অসদাচরণ বলে। সহজ বাংলায় যা &#39;চৌর্যবৃত্তি&#39; (plagiarism)।</p>\r\n\r\n<p>&nbsp;</p>', 1, 2, '2020-09-12 21:54:21', 7, '7.05-38-11-06-09-2019-video-watch-32gb-raber-belt.jpg', '2020-09-12 21:54:21', NULL, NULL, NULL),
(8, 'আগুনের ওপর চটের ছালায় ঘর বেঁধেছি', 'Shajidul rohman', 'tt', '<p>৪ সেপ্টেম্বর শুক্রবার নারায়ণগঞ্জে বাইতুস সালাত মসজিদে বিস্ফোরণের ঘটনায় মৃত্যুর মিছিল বন্ধ হয়নি। এখনো পর্যন্ত মৃতের সংখ্যা ২৮। হাসপাতালে ভর্তি আছেন আরও আটজন, তাঁরাও শঙ্কামুক্ত নন। শেখ হাসিনা জাতীয় বার্ন ইনস্টিটিউটের প্রধান সমন্বয়ক ডা. সামন্ত লাল সেন বলেছেন, এমন পোড়া রোগী তিনি আগে কখনো দেখেননি। এদিকে বিস্ফোরণের কারণ অনুসন্ধানে জেলা প্রশাসন, ফায়ার সার্ভিস, তিতাস গ্যাস কর্তৃপক্ষ, নারায়ণগঞ্জ সিটি করপোরেশন ও ডিপিডিসি পাঁচটি পৃথক তদন্ত কমিটি গঠন করে কাজ করছে। জেলা প্রশাসনের তদন্ত কমিটি গণশুনানিরও আয়োজন করেছে।৪</p>\r\n\r\n<p>সেপ্টেম্বর শুক্রবার নারায়ণগঞ্জে বাইতুস সালাত মসজিদে বিস্ফোরণের ঘটনায় মৃত্যুর মিছিল বন্ধ হয়নি। এখনো পর্যন্ত মৃতের সংখ্যা ২৮। হাসপাতালে ভর্তি আছেন আরও আটজন, তাঁরাও শঙ্কামুক্ত নন। শেখ হাসিনা জাতীয় বার্ন ইনস্টিটিউটের প্রধান সমন্বয়ক ডা. সামন্ত লাল সেন বলেছেন, এমন পোড়া রোগী তিনি আগে কখনো দেখেননি। এদিকে বিস্ফোরণের কারণ অনুসন্ধানে জেলা প্রশাসন, ফায়ার সার্ভিস, তিতাস গ্যাস কর্তৃপক্ষ, নারায়ণগঞ্জ সিটি করপোরেশন ও ডিপিডিসি পাঁচটি পৃথক তদন্ত কমিটি গঠন করে কাজ করছে। জেলা প্রশাসনের তদন্ত কমিটি গণশুনানিরও আয়োজন করেছে।</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>৪ সেপ্টেম্বর শুক্রবার নারায়ণগঞ্জে বাইতুস সালাত মসজিদে বিস্ফোরণের ঘটনায় মৃত্যুর মিছিল বন্ধ হয়নি। এখনো পর্যন্ত মৃতের সংখ্যা ২৮। হাসপাতালে ভর্তি আছেন আরও আটজন, তাঁরাও শঙ্কামুক্ত নন। শেখ হাসিনা জাতীয় বার্ন ইনস্টিটিউটের প্রধান সমন্বয়ক ডা. সামন্ত লাল সেন বলেছেন, এমন পোড়া রোগী তিনি আগে কখনো দেখেননি। এদিকে বিস্ফোরণের কারণ অনুসন্ধানে জেলা প্রশাসন, ফায়ার সার্ভিস, তিতাস গ্যাস কর্তৃপক্ষ, নারায়ণগঞ্জ সিটি করপোরেশন ও ডিপিডিসি পাঁচটি পৃথক তদন্ত কমিটি গঠন করে কাজ করছে। জেলা প্রশাসনের তদন্ত কমিটি গণশুনানিরও আয়োজন করেছে।</p>\r\n\r\n<p>&nbsp;</p>', 1, 4, '2020-09-12 21:55:22', 8, '8.1578584856Xiaomi Mi Band 3 OLED Smart Fitness Wristband Bracelet  Fitness Tracker Heart Rate Monitor Smart Reminder for iPhone, Android phones 1183-1_thumb.jpg', '2020-09-12 21:55:22', NULL, NULL, NULL),
(9, 'আগুনের ওপর চটের ছালায় ঘর বেঁধেছি', 'Shajidul rohman', '556755', '<p>বিস্ফোরণে মসজিদের ছয়টি এসি পুড়ে যায়। উড়ে যায় জানালার কাচ। সঙ্গে সঙ্গে অনেকগুলো অনলাইন সংবাদমাধ্যম আর তার পরদিনের ছাপা মাধ্যমে খবর রটে, এয়ারকন্ডিশন যন্ত্রে বিস্ফোরণ হয়েছে। এটা ঠিক যে প্রথমে সবকিছু ঠিকঠাক জানা যায় না, কিন্তু খবর ধরতে হয়। কিন্তু চিলের পেছনে ছোটার আগে কানে একবার হাত দিয়ে দেখতে বেশি সময় লাগে কি? এয়ারকন্ডিশনার কি সহজে বিস্ফোরিত হয়? কম্প্রেসরের ফ্রেয়ন গ্যাস দাহ্য নয়। কম্প্রেসর বিস্ফোরিত হলে একসঙ্গে ছয়টি কেন হবে? এসব প্রশ্নের যাচাই-বাছাইয়ের সময় না থাকলে খবরের শিরোনাম শুধু এটাই হতে পারত, &lsquo;মসজিদ বিস্ফোরণ&rsquo;।</p>\r\n\r\n<p>বিস্ফোরণে মসজিদের ছয়টি এসি পুড়ে যায়। উড়ে যায় জানালার কাচ। সঙ্গে সঙ্গে অনেকগুলো অনলাইন সংবাদমাধ্যম আর তার পরদিনের ছাপা মাধ্যমে খবর রটে, এয়ারকন্ডিশন যন্ত্রে বিস্ফোরণ হয়েছে। এটা ঠিক যে প্রথমে সবকিছু ঠিকঠাক জানা যায় না, কিন্তু খবর ধরতে হয়। কিন্তু চিলের পেছনে ছোটার আগে কানে একবার হাত দিয়ে দেখতে বেশি সময় লাগে কি? এয়ারকন্ডিশনার কি সহজে বিস্ফোরিত হয়? কম্প্রেসরের ফ্রেয়ন গ্যাস দাহ্য নয়। কম্প্রেসর বিস্ফোরিত হলে একসঙ্গে ছয়টি কেন হবে? এসব প্রশ্নের যাচাই-বাছাইয়ের সময় না থাকলে খবরের শিরোনাম শুধু এটাই হতে পারত, &lsquo;মসজিদ বিস্ফোরণ&rsquo;।</p>\r\n\r\n<p>বিস্ফোরণে মসজিদের ছয়টি এসি পুড়ে যায়। উড়ে যায় জানালার কাচ। সঙ্গে সঙ্গে অনেকগুলো অনলাইন সংবাদমাধ্যম আর তার পরদিনের ছাপা মাধ্যমে খবর রটে, এয়ারকন্ডিশন যন্ত্রে বিস্ফোরণ হয়েছে। এটা ঠিক যে প্রথমে সবকিছু ঠিকঠাক জানা যায় না, কিন্তু খবর ধরতে হয়। কিন্তু চিলের পেছনে ছোটার আগে কানে একবার হাত দিয়ে দেখতে বেশি সময় লাগে কি? এয়ারকন্ডিশনার কি সহজে বিস্ফোরিত হয়? কম্প্রেসরের ফ্রেয়ন গ্যাস দাহ্য নয়। কম্প্রেসর বিস্ফোরিত হলে একসঙ্গে ছয়টি কেন হবে? এসব প্রশ্নের যাচাই-বাছাইয়ের সময় না থাকলে খবরের শিরোনাম শুধু এটাই হতে পারত, &lsquo;মসজিদ বিস্ফোরণ&rsquo;।</p>\r\n\r\n<p>বিস্ফোরণে মসজিদের ছয়টি এসি পুড়ে যায়। উড়ে যায় জানালার কাচ। সঙ্গে সঙ্গে অনেকগুলো অনলাইন সংবাদমাধ্যম আর তার পরদিনের ছাপা মাধ্যমে খবর রটে, এয়ারকন্ডিশন যন্ত্রে বিস্ফোরণ হয়েছে। এটা ঠিক যে প্রথমে সবকিছু ঠিকঠাক জানা যায় না, কিন্তু খবর ধরতে হয়। কিন্তু চিলের পেছনে ছোটার আগে কানে একবার হাত দিয়ে দেখতে বেশি সময় লাগে কি? এয়ারকন্ডিশনার কি সহজে বিস্ফোরিত হয়? কম্প্রেসরের ফ্রেয়ন গ্যাস দাহ্য নয়। কম্প্রেসর বিস্ফোরিত হলে একসঙ্গে ছয়টি কেন হবে? এসব প্রশ্নের যাচাই-বাছাইয়ের সময় না থাকলে খবরের শিরোনাম শুধু এটাই হতে পারত, &lsquo;মসজিদ বিস্ফোরণ&rsquo;।</p>\r\n\r\n<p>&nbsp;</p>', 1, 16, '2020-09-25 10:04:58', 9, '9.1578551343Mini Sewing Machine, Portable Electric Double Speed Sewing Machine with Foot Pedal Power Supply for Household Travel and Beginner - Stitch Set 16 1136-3_thumb.jpg', '2020-09-12 21:56:33', NULL, NULL, NULL),
(10, 'শীতে করোনার দ্বিতীয় তরঙ্গ আসতে পারে: কাদের', 'Shajidul rohman', '6655', '<div class=\"bn-story-element\">\r\n<div class=\"story-element story-element-text\">\r\n<div>\r\n<p>আওয়ামী লীগের সাধারণ সম্পাদক ওবায়দুল কাদের বলেছেন, বিশেষজ্ঞদের মতে আসন্ন শীতে বাংলাদেশে করোনার দ্বিতীয় তরঙ্গ দেখা দিতে পারে। তাই এখন থেকেই সাবধানতা অবলম্বন করে চলতে হবে। বাধ্যতামূলকভাবে মাস্ক পরিধান করতে হবে।</p>\r\n\r\n<div class=\"bn-story-element\">\r\n<div class=\"story-element story-element-text\">\r\n<div>\r\n<p>আওয়ামী লীগের সাধারণ সম্পাদক ওবায়দুল কাদের বলেছেন, বিশেষজ্ঞদের মতে আসন্ন শীতে বাংলাদেশে করোনার দ্বিতীয় তরঙ্গ দেখা দিতে পারে। তাই এখন থেকেই সাবধানতা অবলম্বন করে চলতে হবে। বাধ্যতামূলকভাবে মাস্ক পরিধান করতে হবে।</p>\r\n\r\n<div class=\"bn-story-element\">\r\n<div class=\"story-element story-element-text\">\r\n<div>\r\n<p>আওয়ামী লীগের সাধারণ সম্পাদক ওবায়দুল কাদের বলেছেন, বিশেষজ্ঞদের মতে আসন্ন শীতে বাংলাদেশে করোনার দ্বিতীয় তরঙ্গ দেখা দিতে পারে। তাই এখন থেকেই সাবধানতা অবলম্বন করে চলতে হবে। বাধ্যতামূলকভাবে মাস্ক পরিধান করতে হবে।</p>\r\n\r\n<div class=\"bn-story-element\">\r\n<div class=\"story-element story-element-text\">\r\n<div>\r\n<p>আওয়ামী লীগের সাধারণ সম্পাদক ওবায়দুল কাদের বলেছেন, বিশেষজ্ঞদের মতে আসন্ন শীতে বাংলাদেশে করোনার দ্বিতীয় তরঙ্গ দেখা দিতে পারে। তাই এখন থেকেই সাবধানতা অবলম্বন করে চলতে হবে। বাধ্যতামূলকভাবে মাস্ক পরিধান করতে হবে।</p>\r\n\r\n<p>&nbsp;</p>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>\r\n</div>', 1, 68, '2020-09-25 10:49:06', 10, '10.34-41-06-05-09-2019-hot-shower-one.jpg', '2020-09-25 10:49:06', NULL, 'Php home laravel, cold, fly', 'fff');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'ff', 'suzdonice135@gmail.com', NULL, '$2y$10$rO5BUTNR9Qt7C0AnVXqcEe59KX6Ag9G3kKjPjIbclEfq.uBkAnzTi', NULL, '2020-10-04 20:56:55', '2020-10-04 20:56:55'),
(2, 'milong', 'suzondicde1345@gmail.com', NULL, '$2y$10$QRE.PovuDEFBwXL6jDBHcebl2RxYJOGgKCpk37AspcDOZKdjL8LYe', NULL, '2020-10-05 11:13:12', '2020-10-05 11:13:12'),
(3, 'sujon ali', 'suzonice15@gmail.com', NULL, '$2y$10$6nDfKnpfiyYqkIfE7JwGxORlFPzcS0ZoQ/7qxRis19P8Us/BT0O/K', NULL, '2020-10-05 11:23:18', '2020-10-05 11:23:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `product_id` (`post_id`,`post_name`(191));

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
